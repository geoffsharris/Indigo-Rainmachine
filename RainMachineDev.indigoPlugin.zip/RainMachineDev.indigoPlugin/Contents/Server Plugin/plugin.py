#! /usr/bin/env python
# -*- coding: utf-8 -*-
####################
# Rain Machine Indigo Server Plugin
#
# Copyright (c) 2018-2020 Geoff Harris
#
# All rights reserved. This program and the accompanying materials
# are made available under the terms of the Eclipse Public License v2.0
# which accompanies this distribution, and is available at
#
#
# Contributors:
# Geoff Harris
#
import time
import indigo
from client import Client


################################################################################
class Plugin(indigo.PluginBase):
################################################################################

	def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
		indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
		self.debug = True
		self.rainmachine_accounts = {}
		self.rainmachine_devices = {}
		self.client = Client()
		self.next_update_programs = time.time()

################################################################################
	def __del__(self):
		indigo.PluginBase.__del__(self)

################################################################################
	def startup(self):
		self.debugLog(u"startup called")
		indigo.server.log("startup called")
		self.controllers = self.client.controllers

################################################################################
	def shutdown(self):
		self.debugLog(u"shutdown called")
		indigo.server.log("shutdown called")


################################################################################
	def deviceStartComm(self, device):

		self.debugLog("Starting device: " + device.name)
		if device.pluginProps["deviceMAC"]:
			indigo.server.log("device exists MAC: " + str(device.pluginProps["deviceMAC"]))
		else:
			indigo.server.log("new device")
		if device.id not in self.rainmachine_devices:
			indigo.server.log("Added Device id: " + str(device.id) + " to self.rainmachine_devices")
			self.mac_address = device.pluginProps["deviceMAC"]
		if device.id in self.rainmachine_devices:
			indigo.server.log("Existing Device id: " + str(device.id) + " : MAC = " + self.rainmachine_devices[device.id])
		self.rainmachine_devices[device.id] = device.pluginProps["deviceMAC"]
		#indigo.server.log("Plugin k,v: " + str(self.rainmachine_devices))
		#if device.pluginProps.has_key("connectionType"):
		#	for kd, vd in device.pluginProps.items():
		#		indigo.server.log(str(kd) + " : " + str(vd))
		indigo.server.log("Device Start Communication")
		self.user_name = device.pluginProps["username"]
		self.password = device.pluginProps["password"]
		self.connection_type = device.pluginProps["connectionType"]
		self.ip_address = device.pluginProps["ip_address"]
		self.port = device.pluginProps["port"]
		self.ssl = device.pluginProps["https"]
		self.debugLog("Started device: " + str(device.id))
		self.debugLog(str(device))
		if device.pluginProps["deviceMAC"] not in self.controllers:
			indigo.server.log("Needs to login")
			if self.connection_type == 'Local':
				self.client.load_local(self.ip_address, self.password, port=self.port, ssl=False)
			elif self.connection_type == 'Cloud':
				self.client.load_remote(self.user_name, self.password)
			else:
				indigo.server.log("No, key: does not exists in dictionary")

		self.mac_address = self.rainmachine_devices[device.id]
		self.controller = self.client.controllers[self.mac_address]
		self.program_list = self.controller.programs.all()
		self.zone_list = self.controller.zones.all()

################################################################################
	def deviceStopComm(self,device):
		self.debugLog("Stopping device: " + device.name)
		indigo.server.log("Device Stop Communication")
		if device.id in self.rainmachine_devices:
			device.updateStateImageOnServer(indigo.kStateImageSel.SensorTripped)
			device.updateStateOnServer('deviceIsOnline', value=False, clearErrorState=True)
			del self.rainmachine_devices[device.id]

################################################################################
	def update(self, device):

		indigo.server.log("Update Called")
	"""
	def update(self, device):
		indigo.server.log("Update Called")

		self.activeZonelist = client.zones.all()
		if self.activeZonelist:
			timeStamp = str(indigo.server.getTime())
			#self.debugLog("Timestamp: " + timeStamp)
			device.updateStateOnServer('deviceTimestamp', value=timeStamp, clearErrorState=True)
			counter = 0
			for kd in self.activeZonelist[u'zones']:
				if kd[u'state'] == 1:
					device.updateStateOnServer('zoneNumber', value=str(kd[u'name']), clearErrorState=True)
					device.updateStateOnServer('zoneMinutesLeft', value=(round(kd[u'remaining']/60)), clearErrorState=True)
					counter += 1
			if counter == 0:
				device.updateStateOnServer('zoneNumber', value='none', clearErrorState=True)
				device.updateStateOnServer('zoneMinutesLeft', value='off', clearErrorState=True)
		if time.time() > self.next_update_programs:
			counter = 0
			self.activeProgramlist = client.programs.all()
			for kd in self.activeZonelist[u'zones']:
				if kd[u'state'] == 1:
					device.updateStateOnServer('currentProgram', value=str(kd[u'name']), clearErrorState=True)
					device.updateStateOnServer('programMinutesLeft', value=(round(kd[u'remaining']/60)), clearErrorState=True)
					counter += 1
					self.next_update_programs = time.time() + 60
			if counter == 0:
				device.updateStateOnServer('currentProgram', value='none', clearErrorState=True)
				device.updateStateOnServer('programMinutesLeft', value='off', clearErrorState=True)
				self.next_update_programs = time.time() + 180
	"""

#####################################
############ Run Program ############
#####################################
	def actionRunProgram(self, pluginAction):

		device = indigo.devices[int(pluginAction.props['indigo_rainmachine_controller'])]
		controller = self.controllers[device.pluginProps["deviceMAC"]]
		controller.programs.start(pluginAction.props["ProgramValue"])

	def actionStopProgram(self, pluginAction):

		device = indigo.devices[int(pluginAction.props['indigo_rainmachine_controller'])]
		controller = self.controllers[device.pluginProps["deviceMAC"]]
		controller.programs.stop(pluginAction.props["ProgramValue"])

	#####################################
	############ Run Zones ############
	#####################################
	def actionRunZones(self, pluginAction):

		device = indigo.devices[int(pluginAction.props['indigo_rainmachine_controller'])]
		controller = self.controllers[device.pluginProps["deviceMAC"]]
		controller.zones.start(pluginAction.props["ZoneValue"], pluginAction.props["zoneDuration"])
		indigo.server.log("Zone: " + str(pluginAction.props["ZoneValue"]) + " Time: " + str(pluginAction.props["zoneDuration"]))

	def actionStopZones(self, pluginAction):

		device = indigo.devices[int(pluginAction.props['indigo_rainmachine_controller'])]
		controller = self.controllers[device.pluginProps["deviceMAC"]]
		controller.zones.stop(pluginAction.props["ZoneValue"])
		indigo.server.log("Stopping Zone: " + str(pluginAction.props["ZoneValue"]))


	def actionAllOff(self, pluginAction):

		device = indigo.devices[int(pluginAction.props['indigo_rainmachine_controller'])]
		controller = self.controllers[device.pluginProps["deviceMAC"]]
		controller.zones.stop_all()
		indigo.server.log("Stopping All Called")


	def availableSchedules(self, filter="", valuesDict=None, typeId="", targetId=0):

		passed_schedule_list = []
		if 'indigo_rainmachine_controller' in valuesDict:
			device = indigo.devices[int(valuesDict['indigo_rainmachine_controller'])]
			controller = self.controllers[device.pluginProps['deviceMAC']]
			self.program_list = controller.programs.all()
			passed_schedule_list = [(int(program_dict["uid"]), program_dict["name"]) for program_dict in self.program_list["programs"]]
			self.debugLog("indigo.device.id : " + str(valuesDict['indigo_rainmachine_controller']))
			self.debugLog("indigo.mac.id : " + str(device.pluginProps['deviceMAC']))
		return passed_schedule_list


	def availableZones(self, filter="", valuesDict=None, typeId="", targetId=0):

		passed_zone_list = []
		if 'indigo_rainmachine_controller' in valuesDict:
			device = indigo.devices[int(valuesDict['indigo_rainmachine_controller'])]
			controller = self.controllers[device.pluginProps['deviceMAC']]
			self.zone_list = controller.zones.all()
			passed_zone_list = [(int(zone_dict["uid"]), zone_dict["name"]) for zone_dict in self.zone_list["zones"]]
		return passed_zone_list

	def availableDevices(self, filter="", valuesDict=None, typeId="", targetId=0):

		controller_list = [(controller.mac, controller.name + " : "+ controller.connection_type) for controller in self.client.controllers.values()]
		return controller_list


	def loginDevices(self, valuesDict, typeId, devId):
		if valuesDict["connectionType"] == 'Local':
			self.client.load_local(valuesDict["ip_address"], valuesDict["password"], port=valuesDict["port"], ssl=False)
		elif valuesDict["connectionType"] == 'Cloud':
			self.client.load_remote(valuesDict["username"], valuesDict["password"])
		else:
			indigo.server.log("Error in login")
		pass


	def menuChanged(self, valuesDict, typeId, devId):
		return valuesDict